// script.js - calculator logic + fetch() calls to the backend

const currentEl = document.getElementById("current");
const expressionEl = document.getElementById("expression");

let currentInput = "";   // number being typed
let previousInput = "";  // first number
let operator = "";       // chosen operator
let justCalculated = false;

const symbols = { "+": "+", "-": "−", "*": "×", "/": "÷", "%": "%" };

function updateDisplay() {
  currentEl.classList.remove("error");
  currentEl.textContent = currentInput || previousInput || "0";
  expressionEl.textContent = previousInput && operator
    ? `${previousInput} ${symbols[operator]}`
    : "";
  document.querySelectorAll(".operator").forEach((b) => {
    b.classList.toggle("active", b.dataset.operator === operator && !currentInput);
  });
}

function showError(message) {
  currentInput = "";
  previousInput = "";
  operator = "";
  justCalculated = false;
  expressionEl.textContent = "";
  currentEl.textContent = message;
  currentEl.classList.add("error");
  document.querySelectorAll(".operator").forEach((b) => b.classList.remove("active"));
}

function appendNumber(num) {
  if (justCalculated) { currentInput = ""; justCalculated = false; }
  if (currentInput === "0") currentInput = "";
  if (currentInput.length >= 15) return;
  currentInput += num;
  updateDisplay();
}

function appendDecimal() {
  if (justCalculated) { currentInput = ""; justCalculated = false; }
  if (currentInput.includes(".")) return;
  currentInput = (currentInput || "0") + ".";
  updateDisplay();
}

function deleteLast() {
  if (justCalculated) return;
  currentInput = currentInput.slice(0, -1);
  updateDisplay();
}

function clearAll() {
  currentInput = "";
  previousInput = "";
  operator = "";
  justCalculated = false;
  updateDisplay();
}

// Send the calculation to the backend
async function calculate(num1, num2, op) {
  try {
    const response = await fetch("/api/calculate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ num1: num1, num2: num2, operator: op }),
    });
    const data = await response.json();
    if (!response.ok) {
      return { error: data.error || "Something went wrong" };
    }
    return { result: data.result };
  } catch (err) {
    return { error: "Server error. Is the server running?" };
  }
}

async function chooseOperator(op) {
  if (!currentInput && !previousInput) return;      // nothing typed yet

  // Chain: 5 + 3 then press "*" -> calculate 5 + 3 first
  if (previousInput && currentInput && operator) {
    const out = await calculate(previousInput, currentInput, operator);
    if (out.error) return showError(out.error);
    previousInput = String(out.result);
    currentInput = "";
  } else if (currentInput) {
    previousInput = currentInput;
    currentInput = "";
  }
  operator = op;
  justCalculated = false;
  updateDisplay();
}

async function equals() {
  if (!previousInput || !operator) return;
  if (!currentInput) return showError("Please enter both numbers");

  const out = await calculate(previousInput, currentInput, operator);
  if (out.error) return showError(out.error);

  expressionEl.textContent = `${previousInput} ${symbols[operator]} ${currentInput} =`;
  currentInput = String(out.result);
  previousInput = "";
  operator = "";
  justCalculated = true;
  currentEl.classList.remove("error");
  currentEl.textContent = currentInput;
  document.querySelectorAll(".operator").forEach((b) => b.classList.remove("active"));
}

// Button clicks
document.querySelector(".buttons").addEventListener("click", (e) => {
  const btn = e.target.closest("button");
  if (!btn) return;

  if (btn.dataset.number !== undefined) appendNumber(btn.dataset.number);
  else if (btn.dataset.operator) chooseOperator(btn.dataset.operator);
  else if (btn.dataset.action === "decimal") appendDecimal();
  else if (btn.dataset.action === "delete") deleteLast();
  else if (btn.dataset.action === "clear") clearAll();
  else if (btn.dataset.action === "equals") equals();
});

// Keyboard support
document.addEventListener("keydown", (e) => {
  if (e.key >= "0" && e.key <= "9") appendNumber(e.key);
  else if (e.key === ".") appendDecimal();
  else if (["+", "-", "*", "/", "%"].includes(e.key)) chooseOperator(e.key);
  else if (e.key === "Enter" || e.key === "=") { e.preventDefault(); equals(); }
  else if (e.key === "Backspace") deleteLast();
  else if (e.key === "Escape") clearAll();
});

updateDisplay();
