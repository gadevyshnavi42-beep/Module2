// server.js - Express backend for the calculator
const express = require("express");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());                                   // allow cross-origin requests
app.use(express.json());                           // parse JSON request bodies
app.use(express.static(path.join(__dirname, "public"))); // serve frontend files

const VALID_OPERATORS = ["+", "-", "*", "/", "%"];

// Convert a value to a number. Returns null when it is not a valid number.
function toNumber(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value === "string" && value.trim() !== "") {
    const n = Number(value);
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

// POST /api/calculate
app.post("/api/calculate", (req, res) => {
  const { num1, num2, operator } = req.body || {};

  // 1. Empty input check
  if (num1 === undefined || num1 === null || num1 === "" ||
      num2 === undefined || num2 === null || num2 === "") {
    return res.status(400).json({ error: "Please enter both numbers" });
  }

  // 2. Validate numbers
  const a = toNumber(num1);
  const b = toNumber(num2);
  if (a === null || b === null) {
    return res.status(400).json({ error: "Invalid numbers" });
  }

  // 3. Validate operator
  if (!VALID_OPERATORS.includes(operator)) {
    return res.status(400).json({ error: "Invalid operator" });
  }

  // 4. Calculate
  let result;
  switch (operator) {
    case "+": result = a + b; break;
    case "-": result = a - b; break;
    case "*": result = a * b; break;
    case "/":
      if (b === 0) {
        return res.status(400).json({ error: "Cannot divide by zero" });
      }
      result = a / b;
      break;
    case "%":
      // "b percent of a"  e.g. 200 % 10 = 20
      result = (a * b) / 100;
      break;
  }

  // Fix floating point issues like 0.1 + 0.2 = 0.30000000000000004
  result = parseFloat(result.toPrecision(12));

  res.json({ result });
});

// Handle bad JSON bodies and any other server errors
app.use((err, req, res, next) => {
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ error: "Invalid input" });
  }
  res.status(500).json({ error: "Server error" });
});

app.listen(PORT, () => {
  console.log(`Calculator running at http://localhost:${PORT}`);
});
