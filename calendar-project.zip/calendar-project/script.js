// script.js - Interactive Calendar

const monthNames = ["January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"];
const weekdayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
const weekdayShort = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

// Page elements
const monthYearEl = document.getElementById("monthYear");
const datesEl = document.getElementById("dates");
const weekdaysEl = document.getElementById("weekdays");
const todayTextEl = document.getElementById("todayText");
const selectedTextEl = document.getElementById("selectedText");

// State
const today = new Date();
let currentMonth = today.getMonth();     // 0 - 11
let currentYear = today.getFullYear();
let selectedDate = null;                 // { day, month, year }

// Leap year: divisible by 4, except centuries not divisible by 400
function isLeapYear(year) {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}

// Number of days in a month
function getDaysInMonth(month, year) {
  const days = [31, isLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return days[month];
}

// Format a date like "Tuesday, 29 September 2026"
function formatDate(day, month, year) {
  const weekday = weekdayNames[new Date(year, month, day).getDay()];
  return `${weekday}, ${day} ${monthNames[month]} ${year}`;
}

// Weekday header (Sunday highlighted)
function renderWeekdays() {
  weekdaysEl.innerHTML = "";
  weekdayShort.forEach((name, index) => {
    const div = document.createElement("div");
    div.className = "weekday" + (index === 0 ? " sunday" : "");
    div.textContent = name;
    weekdaysEl.appendChild(div);
  });
}

// Build the date grid
function renderCalendar() {
  monthYearEl.textContent = `${monthNames[currentMonth]} ${currentYear}`;
  datesEl.innerHTML = "";

  const firstDayIndex = new Date(currentYear, currentMonth, 1).getDay(); // 0 = Sunday
  const totalDays = getDaysInMonth(currentMonth, currentYear);

  // Empty cells before day 1
  for (let i = 0; i < firstDayIndex; i++) {
    const empty = document.createElement("div");
    empty.className = "date empty";
    datesEl.appendChild(empty);
  }

  // Day cells
  for (let day = 1; day <= totalDays; day++) {
    const cell = document.createElement("div");
    cell.className = "date";
    cell.textContent = day;

    const weekdayIndex = (firstDayIndex + day - 1) % 7;
    if (weekdayIndex === 0) cell.classList.add("sunday");

    if (day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear()) {
      cell.classList.add("today");
    }

    if (selectedDate && selectedDate.day === day &&
        selectedDate.month === currentMonth && selectedDate.year === currentYear) {
      cell.classList.add("selected");
    }

    cell.addEventListener("click", () => selectDate(day));
    datesEl.appendChild(cell);
  }
}

function selectDate(day) {
  selectedDate = { day: day, month: currentMonth, year: currentYear };
  selectedTextEl.textContent = formatDate(day, currentMonth, currentYear);
  renderCalendar();
}

function previousMonth() {
  currentMonth--;
  if (currentMonth < 0) { currentMonth = 11; currentYear--; }
  renderCalendar();
}

function nextMonth() {
  currentMonth++;
  if (currentMonth > 11) { currentMonth = 0; currentYear++; }
  renderCalendar();
}

function goToToday() {
  currentMonth = today.getMonth();
  currentYear = today.getFullYear();
  selectDate(today.getDate());   // also highlights today's date
}

// Buttons
document.getElementById("prevBtn").addEventListener("click", previousMonth);
document.getElementById("nextBtn").addEventListener("click", nextMonth);
document.getElementById("todayBtn").addEventListener("click", goToToday);

// Initial load
todayTextEl.textContent = "Today: " + formatDate(today.getDate(), today.getMonth(), today.getFullYear());
renderWeekdays();
renderCalendar();
