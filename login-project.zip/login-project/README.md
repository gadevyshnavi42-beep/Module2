# User Login Authentication System

Frontend: HTML5, CSS3, JavaScript | Backend: Node.js, Express, MongoDB, Mongoose, bcryptjs, JWT

## Folder structure
```
login-project/
├── frontend/   (index.html, register.html, dashboard.html, style.css, script.js)
├── backend/    (server.js, package.json, .env, config/, models/, routes/, middleware/)
└── README.md
```

## 1. Install Node.js
Download the LTS version from https://nodejs.org and check:
```
node -v
npm -v
```

## 2. Set up MongoDB
**Option A - Local MongoDB:** install MongoDB Community Server, start it, and keep this in `backend/.env`:
```
MONGO_URI=mongodb://127.0.0.1:27017/login_system
```
**Option B - MongoDB Atlas (cloud):** create a free cluster at https://cloud.mongodb.com, add a database user,
allow your IP under Network Access, click Connect > Drivers, copy the string and put the database name in it:
```
MONGO_URI=mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/login_system
```
The database `login_system` and collection `users` are created automatically on first registration.

## 3. Configure environment
Edit `backend/.env`:
```
PORT=5000
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_secret_key
```
Use a long random string for `JWT_SECRET`.

## 4. Install dependencies and run the backend
```
cd backend
npm install
node server.js
```
You should see: `MongoDB connected: login_system` and `Server running on http://localhost:5000`.

## 5. Run the frontend
Open `frontend/index.html` in your browser (double-click), or use VS Code "Live Server",
or run `npx serve frontend` from the project folder.
The frontend calls `http://localhost:5000/api/auth` (set in `frontend/script.js` as `API_URL`).
If you change `PORT` in `.env`, change `API_URL` too.

## API endpoints
| Method | URL | Description |
|--------|-----|-------------|
| POST | /api/auth/register | Register (name, email, password) |
| POST | /api/auth/login | Login, returns JWT token |
| GET | /api/auth/profile | Protected; header `Authorization: Bearer <token>` |

## Notes
- Passwords are hashed with bcryptjs; plain text is never stored.
- The JWT is kept in `localStorage` and expires after 1 hour. For production, prefer httpOnly cookies and HTTPS.
- "Forgot Password?" is a placeholder link; password reset is not implemented.
