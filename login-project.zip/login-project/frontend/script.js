// Backend API base URL (must match PORT in backend/.env)
const API_URL = "http://localhost:5000/api/auth";

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// ---------- Helpers ----------
function showMessage(text, type) {
  const box = document.getElementById("message");
  if (!box) return;
  box.textContent = text;
  box.className = "message " + type; // error-box | loading-box | success-box
}

function clearMessage() {
  const box = document.getElementById("message");
  if (box) { box.textContent = ""; box.className = "message"; }
}

function setFieldError(inputId, errorId, text) {
  const input = document.getElementById(inputId);
  const err = document.getElementById(errorId);
  if (err) err.textContent = text;
  if (input) input.classList.toggle("invalid", !!text);
}

function setupPasswordToggle() {
  const btn = document.getElementById("togglePassword");
  const input = document.getElementById("password");
  if (!btn || !input) return;
  btn.addEventListener("click", () => {
    const hidden = input.type === "password";
    input.type = hidden ? "text" : "password";
    btn.textContent = hidden ? "Hide" : "Show";
  });
}

setupPasswordToggle();

// ---------- LOGIN PAGE ----------
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  // Already logged in? go to dashboard
  if (localStorage.getItem("token")) window.location.href = "dashboard.html";

  document.getElementById("forgotLink").addEventListener("click", (e) => {
    e.preventDefault();
    alert("Password reset is not implemented in this demo project.");
  });

  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearMessage();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    let valid = true;

    if (!email) { setFieldError("email", "emailError", "Email is required"); valid = false; }
    else if (!emailRegex.test(email)) { setFieldError("email", "emailError", "Please enter a valid email"); valid = false; }
    else setFieldError("email", "emailError", "");

    if (!password) { setFieldError("password", "passwordError", "Password is required"); valid = false; }
    else setFieldError("password", "passwordError", "");

    if (!valid) return;

    const btn = document.getElementById("loginBtn");
    btn.disabled = true;
    showMessage("Logging in, please wait...", "loading-box");

    try {
      const res = await fetch(API_URL + "/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        localStorage.setItem("token", data.token);
        showMessage("Login successful! Redirecting...", "success-box");
        window.location.href = "dashboard.html";
      } else {
        showMessage(data.message || "Login failed", "error-box");
        btn.disabled = false;
      }
    } catch (error) {
      showMessage("Cannot connect to server. Is the backend running?", "error-box");
      btn.disabled = false;
    }
  });
}

// ---------- REGISTER PAGE ----------
const registerForm = document.getElementById("registerForm");
if (registerForm) {
  registerForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    clearMessage();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    let valid = true;

    if (!name) { setFieldError("name", "nameError", "Name is required"); valid = false; }
    else setFieldError("name", "nameError", "");

    if (!email) { setFieldError("email", "emailError", "Email is required"); valid = false; }
    else if (!emailRegex.test(email)) { setFieldError("email", "emailError", "Please enter a valid email"); valid = false; }
    else setFieldError("email", "emailError", "");

    if (!password) { setFieldError("password", "passwordError", "Password is required"); valid = false; }
    else if (password.length < 6) { setFieldError("password", "passwordError", "Password must be at least 6 characters"); valid = false; }
    else setFieldError("password", "passwordError", "");

    if (!valid) return;

    const btn = document.getElementById("registerBtn");
    btn.disabled = true;
    showMessage("Creating account, please wait...", "loading-box");

    try {
      const res = await fetch(API_URL + "/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        showMessage("Registration successful! Redirecting to login...", "success-box");
        setTimeout(() => (window.location.href = "index.html"), 1500);
      } else {
        showMessage(data.message || "Registration failed", "error-box");
        btn.disabled = false;
      }
    } catch (error) {
      showMessage("Cannot connect to server. Is the backend running?", "error-box");
      btn.disabled = false;
    }
  });
}

// ---------- DASHBOARD PAGE ----------
const logoutBtn = document.getElementById("logoutBtn");
if (logoutBtn) {
  const token = localStorage.getItem("token");

  if (!token) {
    window.location.href = "index.html";
  } else {
    // Call protected API with the JWT
    fetch(API_URL + "/profile", {
      headers: { Authorization: "Bearer " + token },
    })
      .then((res) => res.json().then((data) => ({ ok: res.ok, data })))
      .then(({ ok, data }) => {
        if (ok && data.success) {
          document.getElementById("userName").textContent = data.user.name;
          document.getElementById("userEmail").textContent = data.user.email;
          document.getElementById("userJoined").textContent = new Date(data.user.createdAt).toLocaleDateString();
        } else {
          // Token invalid or expired
          localStorage.removeItem("token");
          window.location.href = "index.html";
        }
      })
      .catch(() => showMessage("Cannot connect to server.", "error-box"));
  }

  logoutBtn.addEventListener("click", () => {
    localStorage.removeItem("token");
    window.location.href = "index.html";
  });
}
